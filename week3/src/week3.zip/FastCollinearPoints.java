import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeSet;

public class FastCollinearPoints {
	private static final int NUMBER_OF_SLOPE_TO_CREATE_LINE_SEGMENTS = 3;
	private LineSegment[] segments;

	/**
	 * @param inPoints
	 */
	public FastCollinearPoints(Point[] inPoints) {
		// finds all line segments containing 4 or more points
		if (inPoints == null)
			throw new NullPointerException();
		Point[] points = inPoints.clone();
		LineCollection lines = new LineCollection();
		Arrays.sort(points);

		// make sure all points are different compare to each other
		for (int a = 0; a < points.length - 1; a++) {
			if (points[a].compareTo(points[a + 1]) == 0)
				throw new IllegalArgumentException();
		}

		// for each points
		Point[] p2 = points.clone();
		for (Point p : p2) {
			// sort the other points with default sort then with slopeOrder
			points = p2.clone();
			Arrays.sort(points, p.slopeOrder());
			double lastSlope = Double.NEGATIVE_INFINITY;
			assert lastSlope == p.slopeTo(points[0]);
			int nCount = 1;
			for (int i = 1; i < points.length; i++) {
				double currentSlope = p.slopeTo(points[i]);
				if (currentSlope == lastSlope) {
					nCount++;
				} else {
					if (nCount >= NUMBER_OF_SLOPE_TO_CREATE_LINE_SEGMENTS) {
						assert isSorted(points, i - nCount, i);
						if (p.compareTo(points[i - nCount]) < 0)
							lines.add(p, points[i - 1]);
//						else if (p.compareTo(points[i - 1]) > 0)
//							lines.add(points[i - nCount], p);
//						else
//							lines.add(points[i - nCount], points[i - 1]);
					}
					nCount = 1;
					lastSlope = currentSlope;
				}
			}
			int i = points.length;
			if (nCount >= NUMBER_OF_SLOPE_TO_CREATE_LINE_SEGMENTS) {
				assert isSorted(points, i - nCount, i);
				if (p.compareTo(points[i - nCount]) < 0)
					lines.add(p, points[i - 1]);
//				else if (p.compareTo(points[i - 1]) > 0)
//					lines.add(points[i - nCount], p);
//				else
//					lines.add(points[i - nCount], points[i - 1]);
			}
			//StdOut.println("\n\n");
		}
		segments = lines.toArray();
	}

	private static boolean isSorted(Point[] a, int start, int end) {
		for (int i = start; i < end - 1; i++) {
			if (a[i].compareTo(a[i + 1]) > 0)
				return false;
		}
		return true;
	}

	public int numberOfSegments() {
		return segments.length;
	}

	/**
	 * @return a clone of segments
	 */
	public LineSegment[] segments() {
		return segments.clone();
	}

	/**
	 * This class provides a 'set' to contain line-segments
	 */
	private class LineCollection {
		private ArrayList<Line> lines;

		public LineCollection() {
			lines = new ArrayList<>();
		}

		public void add(Point p1, Point p2) {
			lines.add(new Line(p1, p2));
		}

		public LineSegment[] toArray() {
			LineSegment[] result = new LineSegment[lines.size()];
			int i = 0;
			for (Line l : lines) {
				result[i] = new LineSegment(l.p1, l.p2);
				i++;
			}
			return result;
		}

		private class Line implements Comparable<Line> {
			private Point p1, p2;

			public Line(Point p1, Point p2) {
				this.p1 = p1;
				this.p2 = p2;
			}

			@Override
			public int compareTo(Line o) {
				if (p1.compareTo(o.p1) == 0)
					return p2.compareTo(o.p2);
				else
					return p1.compareTo(o.p1);
			}
		}
	}
}
